package org.example.dao;

import org.example.domain.BabyStroller;
import org.hibernate.query.Query;

public class BabyStrollerDao extends BaseDaoImpl<BabyStroller, Integer> {
    public BabyStrollerDao() {
        super(BabyStroller.class);
    }

    public BabyStroller findOne(Integer id) {
        Query q = getSession().createQuery("FROM BabyStroller WHERE id = :id")
                .setParameter(id, id);
        return (BabyStroller) q.getSingleResult();
    }
}
