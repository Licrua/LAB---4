package org.example.dao;

import org.example.domain.CarSeat;

public class CarSeatDao extends BaseDaoImpl<CarSeat, Integer> {
    public CarSeatDao() {
        super(CarSeat.class);
    }
}
