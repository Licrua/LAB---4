package org.example.dao;

import org.example.domain.Garage;

public class GarageDao extends BaseDaoImpl <Garage, Integer> {
    public GarageDao() {
        super(Garage.class);
    }
}
