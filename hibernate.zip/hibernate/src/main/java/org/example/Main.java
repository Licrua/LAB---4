package org.example;

import org.example.dao.BabyStrollerDao;
import org.example.dao.CarSeatDao;
import org.example.dao.GarageDao;
import org.example.domain.BabyStroller;
import org.example.domain.CarSeat;
import org.example.domain.Garage;
import org.example.util.HibernateUtil;
import org.hibernate.Metamodel;
import org.hibernate.Session;
import org.hibernate.query.Query;

import javax.persistence.metamodel.EntityType;

public class Main {

    public static void main(final String[] args) throws Exception {
        final Session session = HibernateUtil.getSession();
        CarSeatDao carSeatDao = new CarSeatDao();
        GarageDao garageDao = new GarageDao();
        BabyStrollerDao babyStrollerDao = new BabyStrollerDao();


        CarSeat carSeat = new CarSeat("black", 7, "mini");
        Garage garage = new Garage(1, "Moscow", 12, 8);
        BabyStroller babyStroller = new BabyStroller("white", "children", 2, false);
        carSeatDao.save(carSeat);
        garageDao.save(garage);
        babyStrollerDao.save(babyStroller);




        try {
            System.out.println("querying all the managed entities...");
            final Metamodel metamodel = session.getSessionFactory().getMetamodel();
            for (EntityType<?> entityType : metamodel.getEntities()) {
                final String entityName = entityType.getName();
                final Query query = session.createQuery("from " + entityName);
                System.out.println("executing: " + query.getQueryString());
                for (Object o : query.list()) {
                    System.out.println("  " + o);
                }
            }
        } finally {
            session.close();
        }
    }
}