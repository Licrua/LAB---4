package org.example.domain;

import javax.persistence.*;

@Entity
public class Garage {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    private int id;

    private int old;

    private String city;

    private int height;

    private int width;

    public Garage() {
    }


    public Garage(int old, String city, int height, int width) {
        this.old = old;
        this.city = city;
        this.height = height;
        this.width = width;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOld() {
        return old;
    }

    public void setOld(int old) {
        this.old = old;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    @Override
    public String toString() {
        return "Garage{" +
                "id=" + id +
                ", old=" + old +
                ", city='" + city + '\'' +
                ", height=" + height +
                ", width=" + width +
                '}';
    }
}