package org.example.domain;

import javax.persistence.*;

@Entity
public class BabyStroller {
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    @Column(name = "id")
    private int id;

    private String color;

    private String type;

    private int old;

    private boolean isUsed;

    public BabyStroller() {
    }

    public BabyStroller(String color, String type, int old, boolean isUsed) {
        this.color = color;
        this.type = type;
        this.old = old;
        this.isUsed = isUsed;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getOld() {
        return old;
    }

    public void setOld(int old) {
        this.old = old;
    }

    public boolean isUsed() {
        return isUsed;
    }

    public void setUsed(boolean used) {
        isUsed = used;
    }

    @Override
    public String toString() {
        return "BabyStroller{" +
                "id=" + id +
                ", color='" + color + '\'' +
                ", type='" + type + '\'' +
                ", old=" + old +
                ", isUsed=" + isUsed +
                '}';
    }
}
