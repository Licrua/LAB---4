package org.example.domain;

import javax.persistence.*;

@Entity
public class CarSeat {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE)
    private int id;

    private String color;

    private int size;

    private String type;


    public CarSeat() {
    }

    public CarSeat(String color, int size, String type) {
        this.color = color;
        this.size = size;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "CarSeat{" +
                "id=" + id +
                ", color='" + color + '\'' +
                ", size=" + size +
                ", type='" + type + '\'' +
                '}';
    }
}
